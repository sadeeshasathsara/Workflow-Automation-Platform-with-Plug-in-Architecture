from core.interfaces.plugin import Plugin
from core.logging_utils import get_logger
from core.config import get_config_loader


class PluginImpl(Plugin):

    def __init__(self):
        self.logger = get_logger("whatsapp")
        self.config = get_config_loader().get("whatsapp", default={})

    def name(self):
        return "whatsapp"

    def initialize(self, event_bus):
        try:
            self.event_bus = event_bus
            if self.config.get("enabled", True):
                self.event_bus.subscribe("email.received", self.send_whatsapp_message)
                self.logger.info("WhatsApp plugin initialized (phone=%s)", self.config.get("phone_number", "+10000000000"))
            else:
                self.logger.info("WhatsApp plugin disabled in config")
        except Exception as exc:
            self.logger.exception("WhatsApp plugin initialization failed: %s", exc)

    def send_whatsapp_message(self, data):
        try:
            sender = data.get("from", "unknown")
            subject = data.get("subject", "no subject")
            phone_number = self.config.get("phone_number", "+10000000000")
            self.logger.info("WhatsApp message to %s: Email from %s | Subject: %s", phone_number, sender, subject)
        except Exception as exc:
            self.logger.exception("Failed to send WhatsApp message: %s", exc)
